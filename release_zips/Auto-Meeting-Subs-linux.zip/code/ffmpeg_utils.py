import subprocess
import platform
import os
import shutil
import stat
import tarfile
import zipfile
import urllib.request
from pathlib import Path
from better_ffmpeg_progress import FfmpegProcess, FfmpegProcessError

def has_encoder(ffmpeg_path: Path, encoder: str) -> bool:
    """Check if a specific encoder is available in ffmpeg."""
    try:
        result = subprocess.run([str(ffmpeg_path), "-encoders"],capture_output=True,text=True,check=True)
        return encoder in result.stdout
    except Exception:
        return False

def detect_gpu() -> str:
    """
    Detect GPU type on the system.
    Returns: 'nvidia', 'amd', 'intel', or 'none'
    """
    system = platform.system().lower()
    
    if system == "windows":
        try:
            gpu_name = subprocess.run(["powershell", "-Command", "Get-CimInstance -ClassName Win32_VideoController -Property Name | Select-Object -ExpandProperty Name"],capture_output=True,text=True,timeout=5)
        except:
            gpu_name = subprocess.run(["wmic", "path", "win32_videocontroller", "get", "name"],capture_output=True,text=True,timeout=5)
    elif system == "darwin":
        gpu_name =subprocess.run(["system_profiler", "SPDisplaysDataType"],capture_output=True,text=True,timeout=5)
    elif system == "linux":
        gpu_name = subprocess.run(["lspci"],capture_output=True,text=True,timeout=5)
    else:
        return "none", None
    
    gpu_name = gpu_name.stdout.lower()

    encoders_map = {
        "nvidia": ("h264_nvenc", "hevc_nvenc"),
        "intel": ("h264_qsv", "hevc_qsv"),
        "amd": ("h264_amf", "hevc_amf"),
        "apple_silicon": ("h264_videotoolbox", "hevc_videotoolbox"),
    }

    if "apple" in gpu_name or "m1" in gpu_name or "m2" in gpu_name or "m3" in gpu_name:
        return ["apple_silicon", encoders_map["apple_silicon"]]
    elif "nvidia" in gpu_name:
        return ["nvidia", encoders_map["nvidia"]]
    elif "amd" in gpu_name or "radeon" in gpu_name:
        return ["amd", encoders_map["amd"]]
    elif "intel" in gpu_name:
        return ["intel", encoders_map["intel"]]
    else:
        return "none", None

def install_ffmpeg(appdata_dir: Path) -> Path:
    ffmpeg_root = appdata_dir / "ffmpeg"
    ffmpeg_dir = ffmpeg_root / "bin"
    ffmpeg_dir.mkdir(parents=True, exist_ok=True)

    system = platform.system().lower()
    arch = platform.machine().lower()

    ffmpeg_binary = "ffmpeg.exe" if system == "windows" else "ffmpeg"
    ffmpeg_path = ffmpeg_dir / ffmpeg_binary

    gpu, compatible_encoders = detect_gpu()
    # Already installed?
    
    if shutil.which("ffmpeg"):
        ffmpeg_path = shutil.which("ffmpeg")
        ffmpeg_path = Path(ffmpeg_path)
        # Check common GPU encoders
        for gpu_encoder in compatible_encoders:
            if has_encoder(ffmpeg_path, gpu_encoder):
                #print(f"Using system wide install of FFmpeg with {compatible_encoders}")
                return ffmpeg_path
    
    if ffmpeg_path.exists():
        return ffmpeg_path

    print("Installing FFmpeg...")

    if system == "windows":
        # Windows 64-bit full build
        ffmpeg_url = "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip"
        archive_path = ffmpeg_root / "ffmpeg.zip"

        urllib.request.urlretrieve(ffmpeg_url, archive_path)

        with zipfile.ZipFile(archive_path, "r") as zip_ref:
            zip_ref.extractall(ffmpeg_root)
        
        # Find executables recursively
        ffmpeg_exe = next(ffmpeg_root.rglob("ffmpeg.exe"))
        ffprobe_exe = next(ffmpeg_root.rglob("ffprobe.exe"))
        if not ffmpeg_exe or not ffprobe_exe:
            raise RuntimeError("FFmpeg binaries not found after extraction")

        # Move them to your bin directory
        shutil.move(ffmpeg_exe, ffmpeg_dir)
        shutil.move(ffprobe_exe, ffmpeg_dir)

        # Cleanup
        archive_path.unlink()

    elif system == "darwin":
        # Detect Apple Silicon vs Intel
        if arch in ["arm64", "aarch64"]:
            ffmpeg_url = "https://evermeet.cx/ffmpeg/getrelease/ffmpeg/zip"
        else:
            ffmpeg_url = "https://evermeet.cx/ffmpeg/getrelease/ffmpeg/zip"

        archive_path = ffmpeg_root / "ffmpeg.zip"

        urllib.request.urlretrieve(ffmpeg_url, archive_path)

        with zipfile.ZipFile(archive_path, "r") as zip_ref:
            zip_ref.extractall(ffmpeg_dir)

        archive_path.unlink()

    elif system == "linux":
        # Detect architecture
        if arch in ["x86_64", "amd64"] and gpu in ["nvidia", "amd", "intel"]:
            ffmpeg_url = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linux64-gpl.tar.xz"
        elif arch in ["arm64", "aarch64"]:
            ffmpeg_url = "https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-arm64-static.tar.xz"
        else:
            ffmpeg = "https://johnvansickle.com/ffmpeg/builds/ffmpeg-git-amd64-static.tar.xz"

        archive_path = ffmpeg_root / "ffmpeg.tar.xz"

        urllib.request.urlretrieve(ffmpeg_url, archive_path)

        with tarfile.open(archive_path, "r:xz") as tar_ref:
            tar_ref.extractall(ffmpeg_root)

        extracted = next(ffmpeg_root.glob("ffmpeg-*"))
        if arch in ["x86_64", "amd64"] and gpu in ["nvidia", "amd", "intel"]:
            shutil.move(extracted /"bin"/ "ffmpeg", ffmpeg_path)
            shutil.move(extracted /"bin"/ "ffprobe", ffmpeg_dir / "ffprobe")
        else:
            shutil.move(extracted / "ffmpeg", ffmpeg_path)
            shutil.move(extracted / "ffprobe", ffmpeg_dir / "ffprobe")

        shutil.rmtree(extracted)
        archive_path.unlink()

    else:
        raise RuntimeError(f"Unsupported OS: {system}")

    # Ensure executable permissions on Unix
    if system != "windows":
        ffmpeg_path.chmod(ffmpeg_path.stat().st_mode | stat.S_IEXEC)

    print("FFmpeg installed at:", ffmpeg_path)
    return ffmpeg_path


def convert_to_wav(input_file, output_filename_path, dev=False):
    print('\n--------------------------------------------------------------ffmpeg---------------------------------------------------------------------------------------------')

    print(f"\nffmpeg is converting {input_file} to WAV...")
    null_device = "NUL" if os.name == "nt" else "/dev/null"
    # Use ffmpeg to convert the input file to WAV
    command = [
        "ffmpeg",
        "-y",
        "-i", input_file,
        "-vn",                 # no video
        "-c:a", "pcm_s16le",   # WAV PCM encoding
        output_filename_path
    ]
    try:
        if dev:
            subprocess.run(command, check=True)
        else:
            process = FfmpegProcess(command, ffmpeg_log_file=Path(null_device))
            process.run()
        print(f"ffmpeg has converted {input_file} to {output_filename_path}\n")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred:\n{e.stderr.decode() if e.stderr else str(e)}")
    except FfmpegProcessError as e:
        print(f"An error occurred:\n{str(e)}")
    
    return output_filename_path

# Function to compress/convert the audio to mp3
def compressing_audio_to_mp3(Audio_file_path, output_mp3_file, dev=False):
    print('--------------------------------------------------------------ffmpeg---------------------------------------------------------------------------------------------')
    print("ffmpeg is extracting the audio from your WMA file and converting it to MP3...")
    # Use ffmpeg to extract audio from the WMA file and save it as MP3
    command = [
        "ffmpeg",
        "-y",
        "-i", Audio_file_path,
        "-c:a", "libmp3lame",
        output_mp3_file
    ]
    try:
        if dev:
            subprocess.run(command, check=True)
        else:
            process = FfmpegProcess(command)
            process.run()
        print(f"ffmpeg has converted {Audio_file_path} to {output_mp3_file}\n")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred: {e.stderr.decode()}")
    except FfmpegProcessError as e:
        print(f"An error occurred: {str(e)}")

    print("ffmpeg has extracted and converted the audio to MP3 from", Audio_file_path, "\n")
    print('-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')

# Detects hw for video compression 
def detect_best_hwaccel():
    """
    Detect the best available hardware video encoder on the system.
    Returns the codec name for ffmpeg.
    """

    # Run `ffmpeg -encoders` to list available encoders
    try:
        result = subprocess.run(
            ["ffmpeg", "-hide_banner", "-encoders"],
            capture_output=True, text=True
        )
        encoders = result.stdout
    except Exception:
        encoders = ""

    # Order by preference (fastest first)
    preferred_encoders = []

    # NVIDIA GPU
    if "hevc_nvenc" in encoders:
        preferred_encoders.append("hevc_nvenc")
    if "h264_nvenc" in encoders:
        preferred_encoders.append("h264_nvenc")

    # Intel QuickSync
    if "hevc_qsv" in encoders:
        preferred_encoders.append("hevc_qsv")
    if "h264_qsv" in encoders:
        preferred_encoders.append("h264_qsv")

    # AMD VCE / AMF
    if "hevc_amf" in encoders:
        preferred_encoders.append("hevc_amf")
    if "h264_amf" in encoders:
        preferred_encoders.append("h264_amf")

    # Apple VideoToolbox (macOS)
    if platform.system() == "Darwin":
        if "hevc_videotoolbox" in encoders:
            preferred_encoders.append("hevc_videotoolbox")
        if "h264_videotoolbox" in encoders:
            preferred_encoders.append("h264_videotoolbox")

    # Fallback CPU software encoder
    preferred_encoders.append("libx265")  # H.265 CPU fallback
    preferred_encoders.append("libx264")  # H.264 CPU fallback

    # Return the first available encoder from the preferred list
    for codec in preferred_encoders:
        if codec in encoders or codec.startswith("libx"):  # libx always present if ffmpeg installed
            return codec

    # Default fallback
    return "libx265"

# compresses video with ffmpeg 
def compress_video_auto(input_file_path, output_file_path, dev=False):
    """
    Compress a video using FFmpeg with hardware acceleration if available.
    Falls back to CPU if the hardware codec fails.
    Suppresses log file creation by redirecting logs to null device.
    """

    codec = detect_best_hwaccel()  # Your function to choose best codec
    print('--------------------------------------------------------------ffmpeg Compression---------------------------------------------------------------------------------------------')

    # Cross-platform null device for discarding FFmpeg logs
    null_device = "NUL" if os.name == "nt" else "/dev/null"

    cmd = [
        "ffmpeg",
        "-y",
        "-hwaccel", "auto",     # allow GPU decoding if available
        "-i", input_file_path,
        "-c:v", codec,
        "-b:v", "1500k",
        "-preset", "fast",
        "-c:a", "copy",
        output_file_path
    ]

    try:
        if dev:
            # subprocess version (no wrapper)
            subprocess.run(cmd, check=True)
        else:
            print(f"Compressing video using {codec}...")
            process = FfmpegProcess(cmd, ffmpeg_log_file=Path(null_device))
            process.run()
    except subprocess.CalledProcessError:
        if codec.startswith("libx"):
            print(f"CPU fallback {codec} also failed. Cannot continue.")
            return
        # fallback to CPU encoder
        print(f"{codec} failed, falling back to CPU encoder libx265...")
        cmd[cmd.index(codec)] = "libx265"
        if dev:
            subprocess.run(cmd, check=True)
        else:
            print("Compressing video using libx265...")
            process = FfmpegProcess(cmd, ffmpeg_log_file=Path(null_device))
            process.run()

    print("Compression finished.\n")
    print('-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')